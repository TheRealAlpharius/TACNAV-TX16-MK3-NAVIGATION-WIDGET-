-- Copyright 2026 TheRealAlpharius
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
--     http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.

-- =====================================================================
-- TACNAV (LVGL)  : tactical GPS navigation assistant for EdgeTX 2.11+/3.0+
-- Target  : RadioMaster TX16S MK3, 800x480 color/touch, LVGL UI
-- Install : /WIDGETS/TACNAV/main.lua
-- =====================================================================
-- Built on the LVGL Lua API (useLvgl=true). UI objects are created once in
-- update() and updated automatically via GETTER FUNCTIONS - no per-frame
-- redraw. refresh()/background() only read telemetry into state. On-screen
-- LVGL buttons handle paging natively (touch works through LVGL, not events).
--
-- PAGES: NAV (compass+arrows+distances) / WPTS / AAR / GUIDE / DIAG
-- PHILOSOPHY: an assistant, not an autopilot. Pilot owns flight mode.
--   Guidance steers only while the dead-man is held; release = manual.
-- =====================================================================

local NAME = "TACNAV"

-- =====================================================================
-- CONFIG (edit sensor names to match your radio's Telemetry > Discover)
-- =====================================================================
local CFG = {
  src_gps   = "GPS",
  src_alt   = "GAlt",
  src_gspd  = "GSpd",
  src_sats  = "Sats",
  src_hdg_candidates  = { "Hdg", "Yaw" },
  src_link_candidates = { "RQly", "TQly", "1RSS", "RSSI" },

  -- Page selection: physical control read every frame. The MK3 has no 6POS
  -- switch, so we use the S1 knob - rotate it to sweep through the 5 pages.
  -- (Change to "s2", or any switch source, to taste.)
  page_selector = "s1",

  -- Guidance
  guide_enabled   = true,
  ch_roll         = 1,
  ch_yaw          = 4,
  deadman_switch  = "sh",
  deadman_active  = 512,
  gain_roll       = 250,
  gain_yaw        = 120,
  steer_min_speed = 1.0,
  err_deadband_deg= 5,

  -- Waypoint cycling
  cycle_switch    = "sf",
  arrival_dist    = 50,   -- metres: buzz when within this of active waypoint
  cycle_active    = 512,
  haptic_dur      = 60,
  haptic_gap      = 120,

  -- QUICK waypoint (project from HOME along a dialed bearing/distance)
  quick_bearing_src  = "s2",     -- knob for bearing 0-360
  quick_distance_src = "ls",     -- slider for distance
  quick_dist_min     = 100,      -- metres at slider min
  quick_dist_max     = 5000,     -- metres at slider max
  quick_commit_sw    = "sh",     -- momentary: lock the projected point
  quick_commit_active= 512,

  -- Logging
  log_enabled     = true,
  log_interval_s  = 1.0,
  ring_size       = 300,
  log_dir         = "/LOGS",
}

local WPTS = {
  { name="WP1", lat=45.4215, lon=-75.6972 },
  { name="WP2", lat=45.4250, lon=-75.6900 },
  { name="WP3", lat=45.4180, lon=-75.7050 },
}
local HOME = { name="HOME", lat=45.4100, lon=-75.7000, set=true }
-- QUICK: a projected waypoint (from HOME along dialed bearing/distance). set=false
-- until committed. Lives alongside the fixed waypoints.
local QUICK = { name="QUICK", lat=0, lon=0, set=false, brg=0, dist=1000 }

-- =====================================================================
-- GEODESY
-- =====================================================================
local D2R=math.pi/180
local R2D=180/math.pi
local EARTH_M=6371000

local function haversine(la1,lo1,la2,lo2)
  local dLat=(la2-la1)*D2R
  local dLon=(lo2-lo1)*D2R
  local a=math.sin(dLat/2)^2+math.cos(la1*D2R)*math.cos(la2*D2R)*math.sin(dLon/2)^2
  return EARTH_M*2*math.atan(math.sqrt(a),math.sqrt(1-a))
end

local function bearingTo(la1,lo1,la2,lo2)
  local dLon=(lo2-lo1)*D2R
  local y=math.sin(dLon)*math.cos(la2*D2R)
  local x=math.cos(la1*D2R)*math.sin(la2*D2R)-math.sin(la1*D2R)*math.cos(la2*D2R)*math.cos(dLon)
  return (math.atan(y,x)*R2D+360)%360
end

local function angleErr(target,current)
  return (target-current+540)%360-180
end

-- Destination point given start lat/lon, bearing (deg), distance (m).
-- Great-circle "direct" formula. Returns lat,lon.
local function projectPoint(lat, lon, brgDeg, distM)
  local ang = distM / EARTH_M            -- angular distance
  local br = brgDeg * D2R
  local la1 = lat * D2R
  local lo1 = lon * D2R
  local la2 = math.asin(math.sin(la1)*math.cos(ang)
              + math.cos(la1)*math.sin(ang)*math.cos(br))
  local lo2 = lo1 + math.atan(
              math.sin(br)*math.sin(ang)*math.cos(la1),
              math.cos(ang)-math.sin(la1)*math.sin(la2))
  return la2*R2D, ((lo2*R2D+540)%360)-180
end

-- =====================================================================
-- MGRS  (lat/lon -> UTM -> MGRS grid string)
-- =====================================================================
local MGRS_E_LETTERS = {"A","B","C","D","E","F","G","H","J","K","L","M","N","P","Q","R","S","T","U","V","W","X","Y","Z"}
local MGRS_N_LETTERS = {"A","B","C","D","E","F","G","H","J","K","L","M","N","P","Q","R","S","T","U","V"}

local function utmLetter(lat)
  -- latitude band letter
  local bands="CDEFGHJKLMNPQRSTUVWX"
  if lat<-80 or lat>84 then return "Z" end
  local idx=math.floor((lat+80)/8)+1
  if idx<1 then idx=1 elseif idx>#bands then idx=#bands end
  return string.sub(bands,idx,idx)
end

local mgrsCompute  -- forward declaration (defined below)

local function latLonToMGRS(lat,lon)
  if lat==nil or lon==nil then return "----" end
  local ok,result=pcall(function()
    return mgrsCompute(lat,lon)
  end)
  if ok and result then return result end
  -- surface the real error (truncated) so we can see what's wrong
  return "ERR:"..string.sub(tostring(result),1,30)
end

mgrsCompute = function(lat,lon)
  -- WGS84
  local a=6378137.0
  local f=1/298.257223563
  local e2=f*(2-f)
  local zone=math.floor((lon+180)/6)+1
  local lon0=(zone-1)*6-180+3   -- central meridian
  local latR=lat*D2R
  local lonR=lon*D2R
  local lon0R=lon0*D2R
  local N=a/math.sqrt(1-e2*math.sin(latR)^2)
  local T=math.tan(latR)^2
  local C=(e2/(1-e2))*math.cos(latR)^2
  local A=math.cos(latR)*(lonR-lon0R)
  local ep2=e2/(1-e2)
  local M=a*((1-e2/4-3*e2^2/64-5*e2^3/256)*latR
    -(3*e2/8+3*e2^2/32+45*e2^3/1024)*math.sin(2*latR)
    +(15*e2^2/256+45*e2^3/1024)*math.sin(4*latR)
    -(35*e2^3/3072)*math.sin(6*latR))
  local k0=0.9996
  local easting=k0*N*(A+(1-T+C)*A^3/6+(5-18*T+T^2+72*C-58*ep2)*A^5/120)+500000
  local northing=k0*(M+N*math.tan(latR)*(A^2/2+(5-T+9*C+4*C^2)*A^4/24
    +(61-58*T+T^2+600*C-330*ep2)*A^6/720))
  if lat<0 then northing=northing+10000000 end
  -- integer-safe: EdgeTX Lua can error on float % and %d formatting of floats.
  easting=math.floor(easting)
  northing=math.floor(northing)
  zone=math.floor(zone)
  -- floor-based modulo helper (avoids float % issues)
  local function imod(x,m) return x-math.floor(x/m)*m end
  local eHund=math.floor(easting/100000)
  local nHund=math.floor(northing/100000)
  -- column letter set repeats every 3 zones with offset
  local setCol=imod(zone-1,3)*8
  local colLetterIdx=imod(eHund-1+setCol,24)+1
  local colLetter=MGRS_E_LETTERS[colLetterIdx] or "?"
  -- row letters: even zones offset by 5
  local rowOffset=(imod(zone-1,2)==0) and 0 or 5
  local rowLetterIdx=imod(nHund+rowOffset,20)+1
  local rowLetter=MGRS_N_LETTERS[rowLetterIdx] or "?"
  local e5=math.floor(imod(easting,100000))
  local n5=math.floor(imod(northing,100000))
  return string.format("%d%s %s%s %05d %05d",zone,utmLetter(lat),colLetter,rowLetter,e5,n5)
end

-- Find index of a letter in a table; returns nil if absent.
local function letterIdx(tbl,ch)
  for i,v in ipairs(tbl) do if v==ch then return i end end
  return nil
end

-- band letter -> approximate central latitude of that 8-deg band
local function bandCentralLat(bandCh)
  local bands="CDEFGHJKLMNPQRSTUVWX"
  local bi=nil
  for i=1,#bands do if string.sub(bands,i,i)==bandCh then bi=i break end end
  if not bi then return nil end
  return -80 + (bi-1)*8 + 4
end

-- MGRS string -> lat,lon. Returns lat,lon or nil,errstring.
-- Accepts forms like "18T VR 45082 29483" (spaces optional/flexible).
local function mgrsToLatLon(s)
  if type(s)~="string" then return nil,"not string" end
  -- strip spaces, uppercase
  local up=string.upper(s)
  local clean=string.gsub(up,"%s+","")
  -- parse: <zone digits><band><col><row><digits>
  -- zone = leading 1-2 digits
  local zoneStr=string.match(clean,"^(%d%d?)")
  if not zoneStr then return nil,"no zone" end
  local rest=string.sub(clean,#zoneStr+1)
  local band=string.sub(rest,1,1)
  local col=string.sub(rest,2,2)
  local row=string.sub(rest,3,3)
  local nums=string.sub(rest,4)
  if #nums%2~=0 or #nums==0 then return nil,"bad digits" end
  local half=#nums/2
  local eStr=string.sub(nums,1,half)
  local nStr=string.sub(nums,half+1)
  -- pad to 5 digits (precision scaling)
  local function pad5(x)
    local v=tonumber(x) or 0
    local mult=10^(5-#x)
    return v*mult
  end
  local zone=tonumber(zoneStr)
  local easting100=pad5(eStr)
  local northing100=pad5(nStr)
  -- recover 100km square absolute easting/northing
  local imod=function(x,m) return x-math.floor(x/m)*m end
  local setCol=imod(zone-1,3)*8
  local colI=letterIdx(MGRS_E_LETTERS,col)
  if not colI then return nil,"bad col letter" end
  -- eHund: colLetterIdx = imod(eHund-1+setCol,24)+1  => solve eHund
  -- colI-1 = imod(eHund-1+setCol,24)  => eHund-1+setCol ≡ colI-1 (mod24)
  local eHund = imod((colI-1) - setCol, 24) + 1
  local easting = eHund*100000 + easting100
  -- row letter -> nHund (needs band latitude to disambiguate the 2000km cycle)
  local rowOffset=(imod(zone-1,2)==0) and 0 or 5
  local rowI=letterIdx(MGRS_N_LETTERS,row)
  if not rowI then return nil,"bad row letter" end
  -- rowI-1 = imod(nHund+rowOffset,20) => nHund ≡ (rowI-1-rowOffset) mod20
  local nHundMod = imod((rowI-1) - rowOffset, 20)
  -- disambiguate using band central latitude -> approximate northing
  local clat=bandCentralLat(band)
  if not clat then return nil,"bad band" end
  -- approx northing for that latitude (UTM, rough): use meters-per-degree
  local approxN = (clat/0.000008998) -- ~111320 m/deg /... rough; refine via search
  -- Instead of approximating, search the nHund value (0..199) whose 100km band
  -- with nHundMod matches and is nearest the band's expected northing.
  local k0=0.9996
  local a=6378137.0
  local expectedN = a*k0*(clat*D2R) -- rough meridional arc
  local bestNHund=nHundMod
  local bestDiff=1e18
  for cyc=0,9 do
    local cand=nHundMod+cyc*20
    local candN=cand*100000
    local d=math.abs(candN-expectedN)
    if d<bestDiff then bestDiff=d; bestNHund=cand end
  end
  local northing=bestNHund*100000 + northing100

  -- UTM -> lat/lon (inverse)
  local f=1/298.257223563
  local e2=f*(2-f)
  local k0i=0.9996
  local x=easting-500000
  local y=northing
  if clat<0 then y=y-10000000 end
  local M=y/k0i
  local mu=M/(a*(1-e2/4-3*e2*e2/64-5*e2*e2*e2/256))
  local e1=(1-math.sqrt(1-e2))/(1+math.sqrt(1-e2))
  local phi1=mu+(3*e1/2-27*e1^3/32)*math.sin(2*mu)
    +(21*e1*e1/16-55*e1^4/32)*math.sin(4*mu)
    +(151*e1^3/96)*math.sin(6*mu)
  local N1=a/math.sqrt(1-e2*math.sin(phi1)^2)
  local T1=math.tan(phi1)^2
  local ep2=e2/(1-e2)
  local C1=ep2*math.cos(phi1)^2
  local R1=a*(1-e2)/(1-e2*math.sin(phi1)^2)^1.5
  local D=x/(N1*k0i)
  local lat=phi1-(N1*math.tan(phi1)/R1)*(D*D/2
    -(5+3*T1+10*C1-4*C1*C1-9*ep2)*D^4/24
    +(61+90*T1+298*C1+45*T1*T1-252*ep2-3*C1*C1)*D^6/720)
  local lon0=(zone-1)*6-180+3
  local lon=lon0+( (D-(1+2*T1+C1)*D^3/6
    +(5-2*C1+28*T1-3*C1*C1+8*ep2+24*T1*T1)*D^5/120)/math.cos(phi1) )*R2D
  lat=lat*R2D
  return lat,lon
end

-- =====================================================================
-- TELEMETRY (resolve field IDs; GPS must be read by ID per EdgeTX docs)
-- =====================================================================
local function getTeleId(name)
  local f=getFieldInfo(name)
  if f then return f.id end
  return nil
end

local function readGPS()
  local id=getTeleId(CFG.src_gps)
  if not id then return nil,nil end
  local v=getValue(id)
  if type(v)=="table" and v.lat and v.lon and (v.lat~=0 or v.lon~=0) then
    return v.lat,v.lon
  end
  return nil,nil
end

local function readNum(src)
  local v=getValue(src)
  if type(v)=="number" then return v end
  return nil
end

local function readFirst(list)
  for _,s in ipairs(list) do
    local v=getValue(s)
    if type(v)=="number" and v~=0 then return v,s end
  end
  return nil,nil
end

-- =====================================================================
-- STATE  (single shared table; UI getters read from this)
-- =====================================================================
local S = {
  page=1, nPages=7,
  pageNames={"NAV","WPTS","AAR","GUIDE","DIAG","ENTRY","SET"},
  -- MGRS tap-entry state (testing App-mode focus)
  entrySlot=1, entryStr="", entryMsg="", entryMode="keypad",
  -- QUICK page live preview (before commit)
  qPrevBrg=0, qPrevDist=1000, qPrevLat=0, qPrevLon=0, qCommitPrev=0, qMsg="",
  -- shared numeric keypad overlay
  npActive=false, npStr="", npTarget=nil, npLabel="", npMax=nil,
  -- guidance AUTO switch binding
  bindListen=false, boundSwitch=nil, bindBaseline={},
  active=1,
  -- telemetry snapshot
  lat=nil, lon=nil, alt=nil, gspd=nil, sats=nil,
  heading=nil, hdgFromSensor=false,
  linkVal=nil, hasFix=false, fixAge=nil,
  lastLat=nil, lastLon=nil, lastFixTime=nil,
  -- nav solution
  dWp=nil, bWp=nil, dHome=nil, bHome=nil,
  -- guidance
  steerActive=false, steerRoll=0, steerYaw=0, brgErr=nil,
  -- cycling
  cyclePrev=0,
  -- logging
  ring={}, ringHead=0, ringCount=0,
  logFile=nil, logOk=false, lastLogTime=0,
  frame=0,
  -- prefs (persisted)
  units="metric", night=false, trackUp=false, cfgMsg="",
  -- ui bookkeeping
  builtPage=nil,
}

-- Resolve the active nav target. Index 1-3 = WPTS, 4 = HOME. Returns wp table.
local function activeWpt()
  if S.active and S.active>=1 and S.active<=#WPTS then return WPTS[S.active] end
  if S.active==4 and HOME.set then return HOME end
  if S.active==5 and QUICK.set then return QUICK end
  return WPTS[1]
end

-- =====================================================================
-- HEADING
-- =====================================================================
local function updateHeading()
  local hv=readFirst(CFG.src_hdg_candidates)
  if hv then
    S.heading=hv%360
    S.hdgFromSensor=true
  else
    S.hdgFromSensor=false
    local now=getTime()
    if S.lastLat==nil then
      S.lastLat,S.lastLon,S.lastFixTime=S.lat,S.lon,now
      return
    end
    if S.lat~=S.lastLat or S.lon~=S.lastLon then
      S.lastFixTime=now
      if (S.gspd or 0)>=CFG.steer_min_speed then
        S.heading=bearingTo(S.lastLat,S.lastLon,S.lat,S.lon)
      end
      S.lastLat,S.lastLon=S.lat,S.lon
    end
  end
end

-- =====================================================================
-- PERSISTENCE  (save/load waypoints, home, prefs to SD - fully editable)
-- =====================================================================
-- Simple line-based format: KEY=value. Robust, no external libs. Loaded once on
-- startup; saved on deliberate changes. Never locks editing - values load as
-- defaults the pilot can freely change and re-save.
local CFG_FILE="/tacnav_config.txt"  -- SD root (no dir creation needed)

local function ensureDir()
  -- create /TACNAV if missing (io can't mkdir; rely on it existing or LOGS dir).
  -- We attempt a write; if the dir is absent the open fails and we flag it.
end

local function saveConfig()
  local f=io.open(CFG_FILE,"w")
  if not f then S.cfgMsg="SAVE FAILED"; return false end
  io.write(f,"# TACNAV config\n")
  for i,wp in ipairs(WPTS) do
    io.write(f,string.format("WP%d=%.6f,%.6f\n",i,wp.lat,wp.lon))
  end
  io.write(f,string.format("HOME=%.6f,%.6f,%d\n",HOME.lat,HOME.lon,HOME.set and 1 or 0))
  io.write(f,string.format("DEADMAN=%s\n",tostring(CFG.deadman_switch)))
  io.write(f,string.format("UNITS=%s\n",S.units or "metric"))
  io.write(f,string.format("NIGHT=%d\n",S.night and 1 or 0))
  io.write(f,string.format("TRACKUP=%d\n",S.trackUp and 1 or 0))
  io.close(f)
  S.cfgMsg="SAVED"
  return true
end

local function parseLatLon(str)
  local a,b=string.match(str,"([%-%d%.]+),([%-%d%.]+)")
  return tonumber(a),tonumber(b)
end

local function loadConfig()
  local f=io.open(CFG_FILE,"r")
  if not f then S.cfgMsg="no saved config"; return false end
  -- EdgeTX io.read reads N bytes (no line format). Read whole file in chunks.
  local content=""
  while true do
    local chunk=io.read(f,200)
    if not chunk or #chunk==0 then break end
    content=content..chunk
  end
  io.close(f)
  -- split into lines and parse
  for line in string.gmatch(content,"[^\r\n]+") do
    local key,val=string.match(line,"^([%w_]+)=(.+)$")
    if key then
      if string.sub(key,1,2)=="WP" then
        local idx=tonumber(string.sub(key,3))
        if idx and WPTS[idx] then
          local la,lo=parseLatLon(val)
          if la and lo then WPTS[idx].lat=la; WPTS[idx].lon=lo end
        end
      elseif key=="HOME" then
        local la,lo,setf=string.match(val,"([%-%d%.]+),([%-%d%.]+),?(%d?)")
        if la and lo then HOME.lat=tonumber(la); HOME.lon=tonumber(lo)
          HOME.set=(setf~="0") end
      elseif key=="DEADMAN" then CFG.deadman_switch=val; S.boundSwitch=val
      elseif key=="UNITS" then S.units=val
      elseif key=="NIGHT" then S.night=(val=="1")
      elseif key=="TRACKUP" then S.trackUp=(val=="1")
      end
    end
  end
  S.cfgMsg="loaded"
  return true
end

-- =====================================================================
-- LOGGING
-- =====================================================================
local function openLog()
  if not CFG.log_enabled then return end
  local dt=getDateTime()
  local fn=string.format("%s/tacnav_%04d%02d%02d_%02d%02d%02d.csv",
    CFG.log_dir,dt.year,dt.mon,dt.day,dt.hour,dt.min,dt.sec)
  local f=io.open(fn,"w")
  if f then
    io.write(f,"time,lat,lon,alt,hdg,gspd,sats,stale\n")
    S.logFile=f; S.logOk=true
  else
    S.logOk=false
  end
end

local function pushRing(sample)
  S.ringHead=(S.ringHead%CFG.ring_size)+1
  S.ring[S.ringHead]=sample
  if S.ringCount<CFG.ring_size then S.ringCount=S.ringCount+1 end
end

local function logTick()
  if not S.logOk or not S.hasFix then return end
  local now=getTime()
  if (now-S.lastLogTime)<(CFG.log_interval_s*100) then return end
  S.lastLogTime=now
  local dt=getDateTime()
  local stale=(S.fixAge and S.fixAge>3) and 1 or 0
  local sample={
    t=string.format("%02d:%02d:%02d",dt.hour,dt.min,dt.sec),
    lat=S.lat,lon=S.lon,alt=S.alt,hdg=S.heading,gspd=S.gspd,sats=S.sats,stale=stale,
  }
  pushRing(sample)
  if S.logFile then
    io.write(S.logFile,string.format("%s,%.6f,%.6f,%s,%s,%s,%s,%d\n",
      sample.t,sample.lat,sample.lon,
      sample.alt and string.format("%.1f",sample.alt) or "",
      sample.hdg and string.format("%.0f",sample.hdg) or "",
      sample.gspd and string.format("%.1f",sample.gspd) or "",
      sample.sats and string.format("%d",sample.sats) or "",
      sample.stale))
  end
end

-- =====================================================================
-- HAPTICS + CYCLING
-- =====================================================================
local function buzzN(n) for _=1,n do playHaptic(CFG.haptic_dur,CFG.haptic_gap) end end

local function cycleTick()
  local v=getValue(CFG.cycle_switch)
  if type(v)~="number" then return end
  local pressed=(v>=CFG.cycle_active)
  if pressed and S.cyclePrev==0 then
    S.active=(S.active%#WPTS)+1
    buzzN(S.active)
    S.builtPage=nil  -- force WPTS rebuild to refresh highlight
  end
  S.cyclePrev=pressed and 1 or 0
end

-- QUICK waypoint: read bearing/distance controls, compute live preview from HOME,
-- and commit (lock) on the commit switch edge.
local function quickTick()
  -- origin: HOME if set, else current GPS position (so QUICK works pre-home-set)
  local oLat,oLon
  if HOME.set then oLat,oLon=HOME.lat,HOME.lon
  elseif S.hasFix then oLat,oLon=S.lat,S.lon
  else return end   -- no origin available yet
  S.qOrigin = HOME.set and "HOME" or "POS"
  -- Knob control: only override the value when the knob actually MOVES, so the
  -- tap +/- buttons aren't overwritten every frame. Tapping a button sets
  -- S.qManual=true; USE KNOBS button (or moving a knob) re-enables live knob.
  local bv = CFG.quick_bearing_src and getValue(CFG.quick_bearing_src)
  if type(bv)=="number" then
    if S.qLastBv==nil then S.qLastBv=bv end
    if math.abs(bv-S.qLastBv)>10 then S.qManual=false end  -- knob moved -> live
    S.qLastBv=bv
    if not S.qManual then
      S.qPrevBrg=((bv+1024)/2048)*360
      if S.qPrevBrg<0 then S.qPrevBrg=0 elseif S.qPrevBrg>360 then S.qPrevBrg=360 end
    end
  end
  local dv = CFG.quick_distance_src and getValue(CFG.quick_distance_src)
  if type(dv)=="number" then
    if S.qLastDv==nil then S.qLastDv=dv end
    if math.abs(dv-S.qLastDv)>10 then S.qManual=false end
    S.qLastDv=dv
    if not S.qManual then
      local frac=(dv+1024)/2048
      if frac<0 then frac=0 elseif frac>1 then frac=1 end
      S.qPrevDist=CFG.quick_dist_min+frac*(CFG.quick_dist_max-CFG.quick_dist_min)
    end
  end
  -- live preview projection from origin (HOME or current position)
  S.qPrevLat,S.qPrevLon=projectPoint(oLat,oLon,S.qPrevBrg,S.qPrevDist)
  -- commit on switch edge: lock preview into the QUICK waypoint
  local cv = CFG.quick_commit_sw and getValue(CFG.quick_commit_sw)
  if type(cv)=="number" then
    local pressed=(cv>=CFG.quick_commit_active)
    if pressed and S.qCommitPrev==0 then
      QUICK.lat=S.qPrevLat; QUICK.lon=S.qPrevLon
      QUICK.brg=S.qPrevBrg; QUICK.dist=S.qPrevDist
      QUICK.set=true
      S.qMsg=string.format("QUICK set: %03d deg / %dm",math.floor(S.qPrevBrg+0.5)%360,math.floor(S.qPrevDist+0.5))
      buzzN(2)
      S.builtPage=nil
    end
    S.qCommitPrev=pressed and 1 or 0
  end
end

-- AUTO switch binding: when listening, watch all switches; the first one that
-- moves from its baseline becomes the bound guidance switch.
local BIND_CANDIDATES={"sa","sb","sc","sd","se","sf","sg","sh"}
local function bindTick()
  if not S.bindListen then return end
  if S.bindBaseline==nil or next(S.bindBaseline)==nil then
    S.bindBaseline={}
    for _,sw in ipairs(BIND_CANDIDATES) do
      local v=getValue(sw); if type(v)=="number" then S.bindBaseline[sw]=v end
    end
    return
  end
  for _,sw in ipairs(BIND_CANDIDATES) do
    local v=getValue(sw)
    if type(v)=="number" and S.bindBaseline[sw] and math.abs(v-S.bindBaseline[sw])>200 then
      S.boundSwitch=sw
      CFG.deadman_switch=sw
      S.bindListen=false
      S.bindBaseline={}
      buzzN(3)
      saveConfig()
      S.builtPage=nil
      return
    end
  end
end

-- =====================================================================
-- GUIDANCE
-- =====================================================================
-- GUIDANCE: yaw-only nudge toward the active waypoint's bearing. Activation is
-- "bound switch is in its active position" - works as a momentary dead-man (true
-- while held) OR a 3-pos latch (true while in ASSIST position). Pilot picks the
-- switch via AUTO-BIND; the code doesn't care about the switch type.
local function guidanceTick()
  S.steerActive=false; S.steerYaw=0
  if not CFG.guide_enabled then return end
  local sw=getValue(CFG.deadman_switch)
  -- active if switch value is in the upper range (momentary held OR latch in pos)
  if type(sw)~="number" or sw<CFG.deadman_active then return end
  if not S.hasFix or S.heading==nil then return end
  if (S.gspd or 0)<CFG.steer_min_speed then return end
  local wp=activeWpt(); if not wp then return end
  local brg=bearingTo(S.lat,S.lon,wp.lat,wp.lon)
  local err=angleErr(brg,S.heading)
  S.brgErr=err
  if math.abs(err)<CFG.err_deadband_deg then S.steerActive=true; return end
  -- proportional yaw only (roll left to the pilot / FC angle mode)
  local frac=err/90; if frac>1 then frac=1 elseif frac<-1 then frac=-1 end
  S.steerYaw=math.floor(frac*CFG.gain_yaw)
  S.steerActive=true
end

local function applySteer()
  if not CFG.guide_enabled then return end
  -- Yaw-only: GV7 carries the yaw nudge; GV6 (roll) stays zero (pilot/FC own roll).
  model.setGlobalVariable(5,0,0)
  if S.steerActive then
    model.setGlobalVariable(6,0,S.steerYaw)
  else
    model.setGlobalVariable(6,0,0)
  end
end

-- =====================================================================
-- CORE TICK  (telemetry read + nav solve + log + steer). No drawing here.
-- =====================================================================
local function coreTick()
  S.frame=(S.frame+1)%3
  local lat,lon=readGPS()
  S.lat,S.lon=lat,lon
  S.hasFix=(lat~=nil)
  S.alt=readNum(CFG.src_alt)
  S.gspd=readNum(CFG.src_gspd)
  S.sats=readNum(CFG.src_sats)
  S.linkVal=readFirst(CFG.src_link_candidates)
  S.vbat=readNum("RxBt")
  S.txbat=getValue("tx-voltage")
  if type(S.txbat)~="number" then S.txbat=nil end
  S.pitch=readNum("Ptch") or readNum("Pitch")
  S.roll=readNum("Roll")
  if S.hasFix then
    updateHeading()
    if S.lastFixTime then S.fixAge=math.floor((getTime()-S.lastFixTime)/100) end
    local wp=activeWpt()
    if wp then
      S.dWp=haversine(lat,lon,wp.lat,wp.lon)
      S.bWp=bearingTo(lat,lon,wp.lat,wp.lon)
    end
    if HOME.set then
      S.dHome=haversine(lat,lon,HOME.lat,HOME.lon)
      S.bHome=bearingTo(lat,lon,HOME.lat,HOME.lon)
    end
  else
    S.dWp=nil; S.bWp=nil; S.dHome=nil; S.bHome=nil
  end
  -- ARRIVAL ALERT: buzz once when crossing within threshold of active target.
  if S.dWp then
    if S.dWp<=CFG.arrival_dist and not S.arrived then
      S.arrived=true; buzzN(2)
    elseif S.dWp>CFG.arrival_dist*1.5 then
      S.arrived=false  -- re-arm once well outside (hysteresis)
    end
  end
  cycleTick()
  quickTick()
  bindTick()
  guidanceTick()
  applySteer()
  logTick()
end

-- =====================================================================
-- LVGL UI LAYER
-- =====================================================================
-- Colours (LVGL accepts lcd.RGB-style numbers; named constants also exist)
local COL = {
  bg    = lcd.RGB(8,10,12),
  panel = lcd.RGB(20,24,28),
  rule  = lcd.RGB(70,78,86),
  dim   = lcd.RGB(150,160,168),
  text  = lcd.RGB(230,235,240),
  wp    = lcd.RGB(80,200,255),
  home  = lcd.RGB(255,190,70),
  ok    = lcd.RGB(70,210,120),
  warn  = lcd.RGB(245,185,55),
  bad   = lcd.RGB(240,80,80),
  live  = lcd.RGB(160,100,240),
}
-- Night mode: dim/red-shift the palette to preserve dark adaptation. Applied on
-- each buildPage so toggling takes effect immediately.
local function applyPalette()
  if S.night then
    COL.bg=lcd.RGB(4,2,2); COL.panel=lcd.RGB(24,6,6); COL.rule=lcd.RGB(80,20,20)
    COL.dim=lcd.RGB(150,50,50); COL.text=lcd.RGB(230,90,90)
    COL.wp=lcd.RGB(255,120,120); COL.home=lcd.RGB(255,160,90)
    COL.ok=lcd.RGB(200,90,90); COL.warn=lcd.RGB(255,150,60); COL.bad=lcd.RGB(255,60,60)
    COL.live=lcd.RGB(220,100,100)
  else
    COL.bg=lcd.RGB(8,10,12); COL.panel=lcd.RGB(20,24,28); COL.rule=lcd.RGB(70,78,86)
    COL.dim=lcd.RGB(150,160,168); COL.text=lcd.RGB(230,235,240)
    COL.wp=lcd.RGB(80,200,255); COL.home=lcd.RGB(255,190,70)
    COL.ok=lcd.RGB(70,210,120); COL.warn=lcd.RGB(245,185,55); COL.bad=lcd.RGB(240,80,80)
    COL.live=lcd.RGB(160,100,240)
  end
end

local LW, LH = LCD_W, LCD_H   -- 800x480

-- ---- value/label formatters (used inside getter functions) ----------
local function fmtDist(m)
  if m==nil then return "----" end
  if S.units=="imperial" then
    local ft=m*3.28084
    if ft<5280 then return string.format("%dft",math.floor(ft+0.5)) end
    return string.format("%.1fmi",ft/5280)
  end
  if m<1000 then return string.format("%dm",math.floor(m+0.5)) end
  return string.format("%.1fkm",m/1000)
end
local function fmtBrg(d)
  if d==nil then return "---" end
  return string.format("%03dT",math.floor(d+0.5)%360)
end
-- bearing with degree symbol (string.char(176)=degree, EdgeTX-safe)
local DEG = string.char(176)
local function fmtDeg(d)
  if d==nil then return "---" end
  return string.format("%03d",math.floor(d+0.5)%360)..DEG
end

-- Compass geometry (right side of screen)
local CX, CY, CR = LW-200, (LH/2)+18, 180

-- Compute line points {{cx,cy},{tx,ty}} for an arrow at a bearing (north-up).
local function linePts(deg, lenFrac)
  if deg==nil then return {{CX,CY},{CX,CY}} end
  local a=(deg-90)*D2R
  local len=CR*(lenFrac or 0.85)
  return {{CX,CY},{CX+math.cos(a)*len,CY+math.sin(a)*len}}
end

-- getters for arrow bearings (return nil to hide)
local function gHeading() return S.heading end

-- Screen angle for a compass bearing. North-up: as-is. Track-up: rotate by
-- -heading so the drone's track points up (bearing==heading -> top of screen).
local function screenAng(brg)
  if S.trackUp and S.heading then return brg - S.heading end
  return brg
end

-- RADAR-STYLE compass: drone at centre, dots plotted by BEARING and DISTANCE.
-- Ring edge = the farthest waypoint (auto-fit). A dot at 0 distance = centre.
local function setRadarBlip(obj, brg, dist, scale)
  if not obj then return end
  if brg==nil or dist==nil or not S.hasFix then
    lvgl.set(obj,{x=-50,y=-50}); return   -- hide
  end
  local frac = (scale>0) and (dist/scale) or 0
  if frac>1 then frac=1 end               -- clamp to ring edge
  local r = frac*(CR-14)
  local a=(screenAng(brg)-90)*D2R
  lvgl.set(obj,{x=CX+math.cos(a)*r, y=CY+math.sin(a)*r})
end

-- Place an object on the ring at a bearing (applies track-up rotation).
local function setBlip(obj, brg, ringR)
  if not obj then return end
  if brg==nil then lvgl.set(obj,{x=-50,y=-50}); return end
  local a=(screenAng(brg)-90)*D2R
  lvgl.set(obj,{x=CX+math.cos(a)*ringR, y=CY+math.sin(a)*ringR})
end

-- Position a mini dot around a fixed center point (mini circles - always
-- bearing-relative-to-north, NOT rotated; they're small heading indicators).
local function setMiniDot(obj, cx, cy, brg, r)
  if not obj then return end
  if brg==nil then lvgl.set(obj,{x=-50,y=-50}); return end
  local a=(brg-90)*D2R
  lvgl.set(obj,{x=cx+math.cos(a)*r, y=cy+math.sin(a)*r})
end

local function updateArrows()
  if not S.ui then return end
  local scale=50
  if S.dWp and S.dWp>scale then scale=S.dWp end
  if S.dHome and S.dHome>scale then scale=S.dHome end
  setRadarBlip(S.ui.blipWp,   S.bWp,   S.dWp,   scale)
  setRadarBlip(S.ui.blipHome, (HOME.set and S.bHome) or nil, S.dHome, scale)
  -- heading indicator: in track-up it's always at top; in north-up it points to heading
  if S.trackUp then
    setBlip(S.ui.blipHdg, S.heading, CR-64)   -- resolves to top when track-up
  else
    setBlip(S.ui.blipHdg, gHeading(), CR-64)
  end
  -- rotate cardinal letters (N/E/S/W) if track-up
  if S.ui.cards then
    for _,c in ipairs(S.ui.cards) do
      local a=(screenAng(c.brg)-90)*D2R
      lvgl.set(c.obj,{x=CX+math.cos(a)*(CR-26)-6, y=CY+math.sin(a)*(CR-26)-10})
    end
  end
  -- inline mini dots beside bearing numbers (bearing-only, not rotated)
  if S.ui.mWp   then setMiniDot(S.ui.mWp,   S.ui.mWpC[1],  S.ui.mWpC[2],  (S.dWp and S.dWp>15) and S.bWp or nil,    14) end
  if S.ui.mHome then setMiniDot(S.ui.mHome, S.ui.mHomeC[1],S.ui.mHomeC[2],(S.dHome and S.dHome>15) and S.bHome or nil,  14) end
  if S.ui.mHdg  then setMiniDot(S.ui.mHdg,  S.ui.mHdgC[1], S.ui.mHdgC[2], S.heading,14) end
end

-- =====================================================================
-- PAGE BUILDERS  (each builds its LVGL objects; called after lvgl.clear())
-- =====================================================================

-- Shared top status strip (present on every page). No LVGL buttons - they grab
-- input focus in fullscreen widgets and can lock out SYS/MDL. Paging is via the
-- 6POS switch (read every frame in refresh), which is also the in-flight control.
local function buildChrome()
  -- FULL-SCREEN OPAQUE BACKGROUND (so the radio wallpaper doesn't bleed through)
  lvgl.rectangle({x=0,y=0,w=LW,h=LH,color=COL.bg,filled=true})
  -- status strip background
  lvgl.rectangle({x=0,y=0,w=LW,h=34,color=COL.panel,filled=true})
  -- Evenly spaced fields. Order: FIX SAT LNK AGE HDG | DRN(batt) TX(batt) STEER LOG
  lvgl.label({x=10,y=8,font=BOLD,
    text=function() return S.hasFix and "FIX" or "NOFIX" end,
    color=function() return S.hasFix and COL.ok or COL.bad end})
  lvgl.label({x=95,y=8,color=COL.dim,
    text=function() return S.sats and ("SAT "..S.sats) or "SAT --" end})
  lvgl.label({x=195,y=8,color=COL.dim,
    text=function() return S.linkVal and ("LNK "..math.floor(S.linkVal+0.5)) or "LNK --" end})
  lvgl.label({x=305,y=8,color=COL.dim,
    text=function() return S.fixAge and ("AGE "..S.fixAge.."s") or "AGE --" end})
  lvgl.label({x=410,y=8,color=COL.dim,
    text=function() return S.hdgFromSensor and "HDG:SNS" or "HDG:GPS" end})
  -- DRONE battery (RxBt), color-coded
  lvgl.label({x=530,y=8,
    text=function() return S.vbat and string.format("DRN %.1fV",S.vbat) or "DRN --" end,
    color=function()
      if not S.vbat then return COL.dim end
      if S.vbat<10.5 then return COL.bad elseif S.vbat<11.1 then return COL.warn else return COL.ok end
    end})
  -- TX (controller) battery
  lvgl.label({x=650,y=8,
    text=function() return S.txbat and string.format("TX %.1fV",S.txbat) or "TX --" end,
    color=function()
      if not S.txbat then return COL.dim end
      if S.txbat<7.0 then return COL.bad elseif S.txbat<7.4 then return COL.warn else return COL.ok end
    end})
  lvgl.label({x=760,y=8,color=COL.live,
    text=function() return S.steerActive and "STEER" or "" end})
  lvgl.label({x=LW-60,y=8,
    text=function() return S.logOk and "LOG" or "LOG--" end,
    color=function() return S.logOk and COL.ok or COL.dim end})

  -- PAGE TABS: text-labeled buttons, tappable when App-mode focused. (Earlier
  -- overlap of a label + button caused text to bleed behind the white button.)
  local px=8
  for i=1,S.nPages do
    lvgl.button({x=px,y=LH-34,w=76,h=30,text=S.pageNames[i],
      press=(function(idx) return function() S.page=idx; S.builtPage=nil end end)(i)})
    px=px+80
  end
end

-- PAGE 1: NAV
local function buildNav()
  -- compass ring (lvgl.circle x/y is the CENTRE)
  lvgl.circle({x=CX,y=CY,radius=CR,thickness=2,color=COL.rule})
  -- cardinal letters (store handles so they can rotate in track-up mode)
  S.ui = S.ui or {}
  S.ui.cards={}
  local cards={{0,"N",COL.bad},{90,"E",COL.dim},{180,"S",COL.dim},{270,"W",COL.dim}}
  for _,c in ipairs(cards) do
    local a=(c[1]-90)*D2R
    local lx=CX+math.cos(a)*(CR-26)-6
    local ly=CY+math.sin(a)*(CR-26)-10
    local obj=lvgl.label({x=lx,y=ly,text=c[2],color=c[3],font=BOLD})
    S.ui.cards[#S.ui.cards+1]={obj=obj,brg=c[1]}
  end
  -- bearing indicators: instead of arcs (angle-wrap issues) we place a filled
  -- circle "blip" on the compass ring at each bearing. Stored handles are moved
  -- each frame by updateArrows(). North-up: screen angle a=(brg-90)deg.
  S.ui = S.ui or {}
  local function blip(col,r) return lvgl.circle({x=CX,y=CY,radius=r,thickness=r,color=col,filled=true}) end
  S.ui.blipWp   = blip(COL.wp,11)
  S.ui.blipHome = blip(COL.home,11)
  S.ui.blipHdg  = blip(COL.text,8)
  -- hub = the DRONE (centre of the radar)
  lvgl.circle({x=CX,y=CY,radius=6,thickness=6,color=COL.text,filled=true})
  -- ring-range label: what the ring edge represents (auto-fit scale)
  lvgl.label({x=CX-40,y=CY+CR+6,color=COL.dim,
    text=function()
      local scale=50
      if S.dWp and S.dWp>scale then scale=S.dWp end
      if S.dHome and S.dHome>scale then scale=S.dHome end
      return "range "..fmtDist(scale).."  "..(S.trackUp and "[TRK-UP]" or "[N-UP]")
    end})

  -- left readout column
  local lx=24
  -- WAYPOINT block
  lvgl.label({x=lx,y=44,text="WAYPOINT",color=COL.dim})
  lvgl.label({x=lx+120,y=44,color=COL.wp,text=function() local w=activeWpt(); return w and w.name or "--" end})
  lvgl.label({x=lx,y=66,text="DISTANCE TO WP",color=COL.dim})
  lvgl.label({x=lx,y=82,font=DBLSIZE,color=COL.text,text=function() return fmtDist(S.dWp) end})
  lvgl.label({x=lx,y=126,text="BEARING",color=COL.dim})
  lvgl.label({x=lx+110,y=122,font=MIDSIZE,color=COL.wp,
    text=function() if S.dWp and S.dWp<=15 then return "AT WP" end return S.bWp and fmtDeg(S.bWp) or "---" end})
  S.ui.mWpC={lx+240,130}
  lvgl.circle({x=S.ui.mWpC[1],y=S.ui.mWpC[2],radius=18,thickness=2,color=COL.rule})
  S.ui.mWp=lvgl.circle({x=S.ui.mWpC[1],y=S.ui.mWpC[2],radius=5,thickness=5,color=COL.wp,filled=true})

  -- HOME block
  lvgl.label({x=lx,y=166,text="HOME",color=COL.dim})
  lvgl.label({x=lx,y=188,text="DISTANCE TO HOME",color=COL.dim})
  lvgl.label({x=lx,y=204,font=DBLSIZE,color=COL.text,text=function() return fmtDist(S.dHome) end})
  lvgl.label({x=lx,y=248,text="BEARING",color=COL.dim})
  lvgl.label({x=lx+110,y=244,font=MIDSIZE,color=COL.home,
    text=function() if S.dHome and S.dHome<=15 then return "AT HOME" end return S.bHome and fmtDeg(S.bHome) or "---" end})
  S.ui.mHomeC={lx+240,252}
  lvgl.circle({x=S.ui.mHomeC[1],y=S.ui.mHomeC[2],radius=18,thickness=2,color=COL.rule})
  S.ui.mHome=lvgl.circle({x=S.ui.mHomeC[1],y=S.ui.mHomeC[2],radius=5,thickness=5,color=COL.home,filled=true})

  -- HDG / ALT / SPD row
  lvgl.label({x=lx,y=292,text="HDG",color=COL.dim})
  lvgl.label({x=lx,y=308,font=MIDSIZE,color=COL.text,text=function() return S.heading and fmtDeg(S.heading) or "---" end})
  S.ui.mHdgC={lx+95,316}
  lvgl.circle({x=S.ui.mHdgC[1],y=S.ui.mHdgC[2],radius=14,thickness=2,color=COL.rule})
  S.ui.mHdg=lvgl.circle({x=S.ui.mHdgC[1],y=S.ui.mHdgC[2],radius=4,thickness=4,color=COL.text,filled=true})
  lvgl.label({x=lx+140,y=292,text="ALT",color=COL.dim})
  lvgl.label({x=lx+140,y=308,font=MIDSIZE,color=COL.text,text=function() return S.alt and (math.floor(S.alt+0.5).."m") or "---" end})
  lvgl.label({x=lx+270,y=292,text="SPD",color=COL.dim})
  lvgl.label({x=lx+270,y=308,font=MIDSIZE,color=COL.text,text=function() return S.gspd and string.format("%.1f",S.gspd) or "---" end})

  -- current POSITION grid (8-figure) - where the drone actually is
  lvgl.label({x=lx,y=352,text="MY GRID",color=COL.dim})
  lvgl.label({x=lx,y=368,font=MIDSIZE,color=COL.text,
    text=function() return S.hasFix and latLonToMGRS(S.lat,S.lon) or "----" end})

  -- no-fix banner
  lvgl.label({x=CX-150,y=CY-8,color=COL.bad,
    text=function() return S.hasFix and "" or "NO GPS FIX - waiting for satellites" end})
end

-- PAGE 2: WPTS  (selection via cycle switch in flight; no buttons to avoid lockout)
local function buildWpts()
  lvgl.label({x=24,y=38,text="WAYPOINTS - cycle switch selects active",color=COL.dim})
  -- helper to draw one entry row
  local function row(y, name, wp, isActive, isHome, slotIdx)
    lvgl.rectangle({x=24,y=y,w=LW-48,h=54,thickness=2,
      color=function() return isActive() and (isHome and COL.home or COL.wp) or COL.rule end})
    lvgl.label({x=36,y=y+18,text=function() return isActive() and ">" or "" end,
      color=isHome and COL.home or COL.wp,font=BOLD})
    lvgl.label({x=64,y=y+6,font=MIDSIZE,text=name,
      color=function() return isActive() and (isHome and COL.home or COL.wp) or COL.text end})
    lvgl.label({x=200,y=y+4,color=COL.dim,text=function() return string.format("%.5f, %.5f",wp.lat,wp.lon) end})
    lvgl.label({x=200,y=y+28,color=COL.text,text=function() return latLonToMGRS(wp.lat,wp.lon) end})
    lvgl.label({x=LW-330,y=y+14,color=COL.text,
      text=function() if not S.hasFix then return "" end return fmtDist(haversine(S.lat,S.lon,wp.lat,wp.lon)) end})
    lvgl.label({x=LW-240,y=y+14,color=COL.dim,
      text=function() if not S.hasFix then return "" end return fmtBrg(bearingTo(S.lat,S.lon,wp.lat,wp.lon)) end})
    -- SELECT (make active nav target) for all rows; EDIT (keypad) only for
    -- WP1-3 and HOME (slots 1-4). QUICK (slot 5) is set via the QUICK page.
    if slotIdx then
      lvgl.button({x=LW-160,y=y+8,w=64,h=38,text="SEL",
        press=(function(idx) return function() S.active=idx; buzzN(idx>3 and 1 or idx); S.builtPage=nil end end)(slotIdx)})
      if slotIdx<=4 then
        lvgl.button({x=LW-90,y=y+8,w=64,h=38,text="EDIT",
          press=(function(idx) return function()
            S.entrySlot=idx; S.entryStr=""; S.entryMsg=""; S.entryMode="keypad"
            S.page=6; S.builtPage=nil
          end end)(slotIdx)})
      end
    end
  end
  local y0=64
  local spacing=58
  for i,wp in ipairs(WPTS) do
    row(y0+(i-1)*spacing, wp.name, wp, function() return i==S.active end, false, i)
  end
  if HOME.set then
    row(y0+#WPTS*spacing, HOME.name, HOME, function() return S.active==4 end, true, 4)
  end
  if QUICK.set then
    row(y0+(#WPTS+1)*spacing, QUICK.name, QUICK, function() return S.active==5 end, false, 5)
  end
end

-- PAGE 3: AAR
local function buildAar()
  lvgl.label({x=24,y=44,color=COL.dim,
    text=function() return string.format("AFTER-ACTION  (%d samples in RAM, full log on SD)",S.ringCount) end})
  local hx={40,150,360,470,560,650,720}
  local hdr={"TIME","LAT/LON","ALT","HDG","SPD","SAT","ST"}
  for i,h in ipairs(hdr) do lvgl.label({x=hx[i],y=72,text=h,color=COL.dim}) end
  -- 10 rows, each a set of getter labels reading ring (most-recent-first)
  for r=0,9 do
    local y=96+r*28
    local function sample()
      local idx=S.ringHead-r
      if idx<1 then idx=idx+CFG.ring_size end
      return S.ring[idx]
    end
    lvgl.label({x=hx[1],y=y,color=COL.text,text=function() local s=sample(); return s and s.t or "" end})
    lvgl.label({x=hx[2],y=y,color=COL.text,text=function() local s=sample(); return s and string.format("%.4f,%.4f",s.lat,s.lon) or "" end})
    lvgl.label({x=hx[3],y=y,color=COL.text,text=function() local s=sample(); return s and s.alt and string.format("%.0f",s.alt) or "" end})
    lvgl.label({x=hx[4],y=y,color=COL.text,text=function() local s=sample(); return s and s.hdg and string.format("%.0f",s.hdg) or "" end})
    lvgl.label({x=hx[5],y=y,color=COL.text,text=function() local s=sample(); return s and s.gspd and string.format("%.1f",s.gspd) or "" end})
    lvgl.label({x=hx[6],y=y,color=COL.text,text=function() local s=sample(); return s and s.sats and string.format("%d",s.sats) or "" end})
    lvgl.label({x=hx[7],y=y,color=COL.warn,text=function() local s=sample(); return (s and s.stale==1) and "*" or "" end})
  end
end

-- PAGE 4: GUIDE
local function buildGuide()
  lvgl.label({x=24,y=44,text="GUIDANCE  (experimental - assist, not autopilot)",color=COL.dim})
  lvgl.rectangle({x=24,y=78,w=LW-48,h=64,thickness=2,
    color=function() return S.steerActive and COL.live or COL.rule end})
  lvgl.label({x=40,y=98,font=MIDSIZE,
    text=function() return S.steerActive and "STEERING - dead-man held" or "MANUAL - hold dead-man to steer" end,
    color=function() return S.steerActive and COL.live or COL.dim end})
  local y=164
  lvgl.label({x=40,y=y,text="TARGET",color=COL.dim})
  lvgl.label({x=170,y=y,color=COL.wp,text=function() local w=activeWpt(); return w and w.name or "--" end})
  lvgl.label({x=40,y=y+30,text="BRG ERR",color=COL.dim})
  lvgl.label({x=170,y=y+30,color=COL.text,text=function() return S.brgErr and string.format("%+.0f deg",S.brgErr) or "---" end})
  lvgl.label({x=40,y=y+60,text="DIST TO GO",color=COL.dim})
  lvgl.label({x=170,y=y+60,color=COL.text,text=function() return fmtDist(S.dWp) end})
  lvgl.label({x=40,y=y+90,text="YAW CMD",color=COL.dim})
  lvgl.label({x=170,y=y+90,color=COL.text,text=function() return string.format("%+d",S.steerYaw) end})
  lvgl.label({x=40,y=y+120,text="(yaw only - pilot flies tilt/throttle)",color=COL.dim})
  -- preconditions
  local px=440
  lvgl.label({x=px,y=y,text="PRECONDITIONS",color=COL.dim})
  lvgl.label({x=px,y=y+30,text="GPS fix",color=COL.dim})
  lvgl.label({x=px+220,y=y+30,text=function() return S.hasFix and "OK" or "--" end,color=function() return S.hasFix and COL.ok or COL.warn end})
  lvgl.label({x=px,y=y+60,text="Heading valid",color=COL.dim})
  lvgl.label({x=px+220,y=y+60,text=function() return S.heading and "OK" or "--" end,color=function() return S.heading and COL.ok or COL.warn end})
  lvgl.label({x=px,y=y+90,text="Moving",color=COL.dim})
  lvgl.label({x=px+220,y=y+90,text=function() return (S.gspd or 0)>=CFG.steer_min_speed and "OK" or "--" end,color=function() return (S.gspd or 0)>=CFG.steer_min_speed and COL.ok or COL.warn end})

  -- AUTO switch binding
  local by=y+140
  lvgl.label({x=40,y=by,text="DEAD-MAN SWITCH:",color=COL.dim})
  lvgl.label({x=280,y=by,color=COL.wp,
    text=function() return S.boundSwitch and string.upper(S.boundSwitch) or string.upper(CFG.deadman_switch or "--") end})
  lvgl.button({x=40,y=by+30,w=260,h=52,
    text=function() return S.bindListen and "FLIP A SWITCH NOW..." or "AUTO-BIND SWITCH" end,
    press=function()
      S.bindListen=true; S.bindBaseline={}; S.builtPage=nil
    end})
  lvgl.label({x=320,y=by+44,color=COL.dim,
    text=function() return S.bindListen and "move the switch you want to use" or "tap, then flip your chosen switch" end})
end

-- PAGE 5: DIAG
local function buildDiag()
  lvgl.label({x=24,y=42,text="DIAGNOSTICS",color=COL.dim})
  local rows={
    {"GPS lat",function() return S.lat and string.format("%.6f",S.lat) or "no fix" end},
    {"GPS lon",function() return S.lon and string.format("%.6f",S.lon) or "no fix" end},
    {"Altitude",function() return S.alt and string.format("%.1f m",S.alt) or "--" end},
    {"Ground speed",function() return S.gspd and string.format("%.2f",S.gspd) or "--" end},
    {"Satellites",function() return S.sats and tostring(S.sats) or "--" end},
    {"Heading",function() return S.heading and string.format("%.0f deg",S.heading) or "--" end},
    {"Heading src",function() return S.hdgFromSensor and "sensor" or "GPS motion" end},
    {"Pitch",function() return S.pitch and string.format("%.1f",S.pitch) or "--" end},
    {"Roll",function() return S.roll and string.format("%.1f",S.roll) or "--" end},
    {"Drone batt",function() return S.vbat and string.format("%.2fV",S.vbat) or "--" end},
    {"TX batt",function() return S.txbat and string.format("%.2fV",S.txbat) or "--" end},
    {"Link",function() return S.linkVal and string.format("%.0f",S.linkVal) or "--" end},
    {"Log",function() return S.logOk and "writing SD" or "off/fail" end},
    {"RAM samples",function() return string.format("%d/%d",S.ringCount,CFG.ring_size) end},
  }
  -- two columns to avoid vertical overflow
  local half=math.ceil(#rows/2)
  for i,r in ipairs(rows) do
    local col=(i<=half) and 0 or 1
    local rowN=(i<=half) and (i-1) or (i-half-1)
    local cx=40+col*380
    local y=76+rowN*34
    lvgl.label({x=cx,y=y,text=r[1],color=COL.dim})
    lvgl.label({x=cx+180,y=y,text=r[2],color=COL.text})
  end
  lvgl.label({x=40,y=330,color=COL.dim,text="Edit sensor names in CFG block at top of main.lua"})
end

-- PAGE 6: ENTRY  (MGRS keypad - bench use; LVGL buttons only on this page)
-- MGRS structure by position in entryStr (letters only, no spaces stored):
--   pos 1-2 = zone digits, 3 = band letter, 4 = col letter, 5 = row letter,
--   6-15 = easting(5)+northing(5) digits. We show only valid keys per position.
local SLOT_NAMES={"WP1","WP2","WP3","HOME"}
local function entryTarget()
  if S.entrySlot<=#WPTS then return WPTS[S.entrySlot] end
  return HOME
end

-- ENTRY sub-page: MGRS keypad (type an exact grid)
local openNumpad  -- forward declaration; defined below
local function buildEntryKeypad()
  lvgl.label({x=24,y=88,text="EDIT:",color=COL.dim})
  local sx=90
  for i=1,4 do
    lvgl.button({x=sx,y=84,w=90,h=32,text=SLOT_NAMES[i],
      press=(function(idx) return function() S.entrySlot=idx; S.entryStr=""; S.entryMsg=""; S.builtPage=nil end end)(i)})
    sx=sx+98
  end
  -- readback
  lvgl.label({x=24,y=126,text="GRID:",color=COL.dim})
  lvgl.label({x=110,y=122,font=MIDSIZE,color=COL.wp,
    text=function()
      local s=S.entryStr
      local out=string.sub(s,1,3)
      if #s>3 then out=out.." "..string.sub(s,4,5) end
      if #s>5 then out=out.." "..string.sub(s,6) end
      return out~="" and out or "(empty)"
    end})
  lvgl.label({x=24,y=156,color=COL.ok,text=function() return S.entryMsg end})

  local n=#S.entryStr
  local mode
  if n<2 then mode="zone" elseif n<5 then mode="letter" else mode="num" end
  local hint
  if mode=="zone" then hint="enter 2-digit UTM zone"
  elseif mode=="letter" then hint="enter grid letter ("..(n==2 and "band" or n==3 and "column" or "row")..")"
  else hint="enter "..(10-(n-5)).." more digits (E then N)" end
  lvgl.label({x=24,y=184,color=COL.dim,text=hint})

  local function appendKey(ch) return function()
    if #S.entryStr<15 then S.entryStr=S.entryStr..ch; S.builtPage=nil end
  end end
  local keys={}
  if mode=="num" or mode=="zone" then
    keys={"1","2","3","4","5","6","7","8","9","0"}
  else
    for _,c in ipairs({"A","B","C","D","E","F","G","H","J","K","L","M","N","P","Q","R","S","T","U","V","W","X","Y","Z"}) do keys[#keys+1]=c end
  end
  local kx,ky=24,212
  local kw,kh=62,42
  local perRow=10
  for i,k in ipairs(keys) do
    local col=(i-1)%perRow
    local rowN=math.floor((i-1)/perRow)
    lvgl.button({x=kx+col*(kw+6),y=ky+rowN*(kh+6),w=kw,h=kh,text=k,press=appendKey(k)})
  end
  local ay=ky+3*(kh+6)+8
  lvgl.button({x=24,y=ay,w=110,h=42,text="DEL",
    press=function() if #S.entryStr>0 then S.entryStr=string.sub(S.entryStr,1,#S.entryStr-1); S.builtPage=nil end end})
  lvgl.button({x=142,y=ay,w=120,h=42,text="CLEAR",
    press=function() S.entryStr=""; S.entryMsg=""; S.builtPage=nil end})
  lvgl.button({x=270,y=ay,w=200,h=42,text="SET WAYPOINT",
    press=function()
      local good,rlat,rlon=pcall(mgrsToLatLon,S.entryStr)
      if good and type(rlat)=="number" and type(rlon)=="number" then
        local t=entryTarget()
        t.lat=rlat; t.lon=rlon
        if t==HOME then HOME.set=true end
        S.entryMsg=string.format("SET %s ok",SLOT_NAMES[S.entrySlot])
        buzzN(1)
        saveConfig()
      else
        S.entryMsg="INVALID GRID"
      end
      S.builtPage=nil
    end})
end

-- ENTRY sub-page: QUICK mission (project from HOME via knobs)
local function buildEntryQuick()
  lvgl.label({x=24,y=88,color=COL.dim,
    text=function() return "Project from "..(S.qOrigin or "HOME")..". Tap a value to type it." end})

  -- BEARING - tap to open numpad
  lvgl.label({x=24,y=126,text="BEARING",color=COL.dim})
  lvgl.button({x=170,y=118,w=200,h=52,
    text=function() return string.format("%03d",math.floor(S.qPrevBrg+0.5)%360)..DEG end,
    press=function()
      openNumpad("BEARING (0-359)",S.qPrevBrg,359,function(v)
        S.qPrevBrg=v%360; S.qManual=true end)
    end})

  -- DISTANCE - tap to open numpad
  lvgl.label({x=24,y=196,text="DISTANCE (m)",color=COL.dim})
  lvgl.button({x=170,y=188,w=200,h=52,
    text=function() return fmtDist(S.qPrevDist) end,
    press=function()
      openNumpad("DISTANCE metres",S.qPrevDist,CFG.quick_dist_max,function(v)
        if v<CFG.quick_dist_min then v=CFG.quick_dist_min end
        S.qPrevDist=v; S.qManual=true end)
    end})

  -- projected grid
  lvgl.label({x=24,y=262,text="PROJECTED GRID:",color=COL.dim})
  lvgl.label({x=24,y=290,font=MIDSIZE,color=COL.text,
    text=function() return latLonToMGRS(S.qPrevLat,S.qPrevLon) end})
  lvgl.label({x=24,y=330,color=COL.ok,text=function() return S.qMsg end})

  lvgl.button({x=24,y=360,w=260,h=54,text="COMMIT QUICK WP",
    press=function()
      QUICK.lat=S.qPrevLat; QUICK.lon=S.qPrevLon
      QUICK.brg=S.qPrevBrg; QUICK.dist=S.qPrevDist
      QUICK.set=true
      S.qMsg=string.format("QUICK set: %03dT / %dm",math.floor(S.qPrevBrg+0.5)%360,math.floor(S.qPrevDist+0.5))
      buzzN(2)
      S.builtPage=nil
    end})
  lvgl.button({x=300,y=360,w=200,h=54,text="USE KNOBS",
    press=function() S.qManual=false; S.builtPage=nil end})
  -- go straight to navigating the committed QUICK
  lvgl.button({x=516,y=360,w=200,h=54,text="GO (NAV QUICK)",
    press=function()
      if QUICK.set then S.active=5; S.page=1; S.builtPage=nil; buzzN(1) end
    end})

  if not HOME.set and not S.hasFix then
    lvgl.label({x=24,y=418,color=COL.warn,text="Waiting for GPS fix to establish an origin..."})
  end
end

-- ===================== SHARED NUMERIC KEYPAD OVERLAY =====================
-- Open the numpad to edit a numeric field. onApply(value) is called on ENTER.
openNumpad = function(label, initial, maxVal, onApply)
  S.npActive=true
  S.npStr= initial and tostring(math.floor(initial+0.5)) or ""
  S.npLabel=label
  S.npMax=maxVal
  S.npApply=onApply
  S.builtPage=nil
end

local function buildNumpad()
  -- dim backdrop
  lvgl.rectangle({x=0,y=0,w=LW,h=LH,color=COL.bg,filled=true})
  lvgl.label({x=40,y=40,font=MIDSIZE,color=COL.warn,text="ENTER "..S.npLabel})
  lvgl.label({x=40,y=90,font=DBLSIZE,color=COL.wp,
    text=function() return S.npStr~="" and S.npStr or "_" end})
  if S.npMax then
    lvgl.label({x=40,y=150,color=COL.dim,text="max "..tostring(S.npMax)})
  end
  local function press(d) return function()
    if #S.npStr<7 then S.npStr=S.npStr..d; S.builtPage=nil end
  end end
  local keys={"1","2","3","4","5","6","7","8","9","0"}
  local kx,ky,kw,kh=40,200,90,64
  for i,k in ipairs(keys) do
    local col=(i-1)%5
    local rowN=math.floor((i-1)/5)
    lvgl.button({x=kx+col*(kw+10),y=ky+rowN*(kh+10),w=kw,h=kh,text=k,press=press(k)})
  end
  local ay=ky+2*(kh+10)+16
  lvgl.button({x=40,y=ay,w=140,h=56,text="DEL",
    press=function() if #S.npStr>0 then S.npStr=string.sub(S.npStr,1,#S.npStr-1); S.builtPage=nil end end})
  lvgl.button({x=190,y=ay,w=160,h=56,text="CANCEL",
    press=function() S.npActive=false; S.builtPage=nil end})
  lvgl.button({x=360,y=ay,w=220,h=56,text="ENTER",
    press=function()
      local v=tonumber(S.npStr)
      if v then
        if S.npMax and v>S.npMax then v=S.npMax end
        if S.npApply then S.npApply(v) end
      end
      S.npActive=false; S.builtPage=nil
    end})
end

local function buildEntry()
  -- sub-mode toggle: KEYPAD (type grid) vs QUICK (project from HOME)
  lvgl.button({x=24,y=42,w=200,h=36,text="GRID KEYPAD",
    press=function() S.entryMode="keypad"; S.builtPage=nil end})
  lvgl.button({x=234,y=42,w=200,h=36,text="QUICK MISSION",
    press=function() S.entryMode="quick"; S.builtPage=nil end})

  if S.entryMode=="quick" then
    buildEntryQuick()
  else
    buildEntryKeypad()
  end
end

-- PAGE 7: SETTINGS
local function buildSettings()
  lvgl.label({x=24,y=44,text="SETTINGS",color=COL.dim})
  -- units toggle
  lvgl.label({x=40,y=90,text="UNITS",color=COL.dim})
  lvgl.button({x=200,y=82,w=180,h=44,
    text=function() return S.units=="imperial" and "IMPERIAL" or "METRIC" end,
    press=function() S.units=(S.units=="imperial") and "metric" or "imperial"; saveConfig(); S.builtPage=nil end})
  -- night mode toggle
  lvgl.label({x=40,y=150,text="NIGHT MODE",color=COL.dim})
  lvgl.button({x=200,y=142,w=180,h=44,
    text=function() return S.night and "NIGHT ON" or "NIGHT OFF" end,
    press=function() S.night=not S.night; saveConfig(); S.builtPage=nil end})
  -- compass orientation toggle
  lvgl.label({x=40,y=210,text="COMPASS",color=COL.dim})
  lvgl.button({x=200,y=202,w=180,h=44,
    text=function() return S.trackUp and "TRACK-UP" or "NORTH-UP" end,
    press=function() S.trackUp=not S.trackUp; saveConfig(); S.builtPage=nil end})
  -- manual save/load
  lvgl.button({x=40,y=270,w=200,h=50,text="SAVE CONFIG",
    press=function() saveConfig(); S.builtPage=nil end})
  lvgl.button({x=260,y=270,w=200,h=50,text="RELOAD CONFIG",
    press=function() loadConfig(); S.builtPage=nil end})
  lvgl.label({x=40,y=336,color=COL.ok,text=function() return "config: "..(S.cfgMsg or "") end})
  lvgl.label({x=40,y=366,color=COL.dim,text="Saved to SD root; all values stay editable."})
end

-- Build the current page (called when page changes).
local function buildPage()
  applyPalette()
  lvgl.clear()
  S.ui={}  -- clear stale object handles (lvgl.clear deleted the objects)
  -- numpad overlay takes over the whole screen when active
  if S.npActive then buildNumpad(); S.builtPage=S.page; return end
  buildChrome()
  local p=S.page
  if p==1 then buildNav()
  elseif p==2 then buildWpts()
  elseif p==3 then buildAar()
  elseif p==4 then buildGuide()
  elseif p==5 then buildDiag()
  elseif p==6 then buildEntry()
  else buildSettings() end
  S.builtPage=p
end

-- =====================================================================
-- WIDGET LIFECYCLE
-- =====================================================================
local function create(zone,options)
  loadConfig()   -- restore saved waypoints/home/prefs (editable defaults)
  return { zone=zone, options=options }
end

local function update(widget,options)
  widget.options=options
  if lvgl==nil then return end
  S.builtPage=nil  -- force rebuild on next refresh (handles layout/fullscreen change)
end

local function refresh(widget,event,touchState)
  if lvgl==nil then
    lcd.drawText(10,10,"LVGL required (EdgeTX 2.11+)",COLOR_THEME_WARNING or 0)
    return
  end
  coreTick()
  -- PAGE SELECTION via physical control (read every frame, reliable). Uses the
  -- S1 knob: full-left=NAV ... centre=AAR ... full-right=DIAG. Always works
  -- because getValue is the same path telemetry uses.
  if CFG.page_selector then
    local pv=getValue(CFG.page_selector)
    if type(pv)=="number" then
      local frac=(pv+1024)/2048
      if frac<0 then frac=0 elseif frac>1 then frac=1 end
      local pg=math.floor(frac*S.nPages)+1
      if pg>S.nPages then pg=S.nPages end
      -- act only when the knob MOVES to a new band, so tab taps aren't overridden
      if S.lastKnobPage==nil then S.lastKnobPage=pg; S.page=pg end
      if pg~=S.lastKnobPage then
        S.page=pg; S.builtPage=nil; S.lastKnobPage=pg
      end
    end
  end
  -- (re)build UI only when the page changes; getters handle live values
  if S.builtPage~=S.page then buildPage() end
  -- arrows can't use getters, so update their points each frame on NAV
  if S.page==1 then updateArrows() end
end

local function background(widget)
  coreTick()
end

return {
  name=NAME, options={},
  create=create, update=update, refresh=refresh, background=background,
  useLvgl=true,
}
