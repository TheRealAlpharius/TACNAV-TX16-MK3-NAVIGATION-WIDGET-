Place screenshots here (nav.png, wpts.png, guide.png, entry.png).
